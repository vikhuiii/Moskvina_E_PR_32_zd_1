﻿

int count = 0;
int count2 = 0;
while (true)
{
    Console.WriteLine("Количество девочек:");
    count = Convert.ToInt32(Console.ReadLine());
    if (count > 0)break;
}
int[] girls = new int[count];
Console.WriteLine("Рост:");
for (int i=0;i< count; i++)
{
        int s= Convert.ToInt32(Console.ReadLine());
    if (s >= 1000 && s <= 2050)
        girls[i] = s;
    else
    {
        Console.WriteLine("Вы вышли за диапазон");
        return;
    }
}


while (true)
{
    Console.WriteLine("Количество мальчиков:");
    count2 = Convert.ToInt32(Console.ReadLine());
    if(count2 > 0&&count2<=1000000) break;
}
int[] boys = new int[count2];
Console.WriteLine("Рост:");
for (int i = 0; i < count2; i++)
{
    int s = Convert.ToInt32(Console.ReadLine());
    if (s >= 1000 && s <= 2050)
        boys[i] = s;
    else
    {
        Console.WriteLine("Вы вышли за диапазон");
        return;
    }
}

int rez=0;
if (count < count2)
{
    for(int i=0; i < count; i++)
    {
        if (girls[i] < boys[i]) rez++;
    }
}
else
{
    for (int i = 0; i < count2; i++)
    {
        if (girls[i] < boys[i]) rez++;
    }
}
File.WriteAllText("output.txt", Convert.ToString(rez));
Console.WriteLine($"Результат: {rez}");
