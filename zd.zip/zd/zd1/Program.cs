﻿int n, k1, t1, k2, t2;

    string s = File.ReadAllText("input.txt");
    int ind=s.IndexOf(' ');
    n = Convert.ToInt32(s.Substring(ind,2));
    ind = s.IndexOf(" ", ind);
    k1 = Convert.ToInt32(s.Substring(ind, 2));
    ind = s.IndexOf(" ", ind);
    t1 = Convert.ToInt32(s.Substring(ind, 2));
    ind = s.IndexOf(" ", ind);
    k2 = Convert.ToInt32(s.Substring(ind, 2));
    ind = s.IndexOf(" ", ind);
    t2 = Convert.ToInt32(s.Substring(ind, 2));

    int rez1 = (n / k1) * t2;
    int rez2 = (n / k2) * t2;
    if(rez1 > rez2)
    {
        File.WriteAllText("output.txt", Convert.ToString(rez2));
    }
    else
    {
        File.WriteAllText("output.txt", Convert.ToString(rez1));
    }


